from setuptools import setup, find_packages

setup(
    name="ci_cd_test_project",
    version="1.0",
    packages=find_packages(),
)
