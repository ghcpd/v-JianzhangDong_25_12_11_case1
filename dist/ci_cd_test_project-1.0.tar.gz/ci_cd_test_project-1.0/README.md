
Environment Name: VirtualEnvironment
Absolute Path: d:\vscoderprojects\v-JianzhangDong_25_12_11_case1\grok-fast\v-JianzhangDong_25_12_11_case1
Python Version: Python 3.14.0
Pip Version: 25.2
