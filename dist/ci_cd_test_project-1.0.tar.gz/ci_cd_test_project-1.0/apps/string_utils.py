def to_upper(s):
    return s.upper()

def reverse(s):
    return s[::-1]

def concat(a, b):
    return a + b
